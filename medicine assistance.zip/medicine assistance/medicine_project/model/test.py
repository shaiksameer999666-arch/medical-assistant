from predict import predict

print(predict("../datasets/images/Dolo650/img1.jpg"))