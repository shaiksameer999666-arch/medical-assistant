import tensorflow as tf
import numpy as np
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL_PATH = os.path.join(BASE_DIR, "medicine_model.keras")
LABEL_PATH = os.path.join(BASE_DIR, "labels.txt")

model = tf.keras.models.load_model(MODEL_PATH)

with open(LABEL_PATH) as f:
    labels = [line.strip() for line in f]


def predict(image_path):

    img = tf.keras.utils.load_img(
        image_path,
        target_size=(224,224)
    )

    img = tf.keras.utils.img_to_array(img)

    img = tf.expand_dims(img,0)

    prediction = model.predict(img, verbose=0)

    index = np.argmax(prediction)

    confidence = float(prediction[0][index])*100

    return labels[index], confidence