import easyocr
import cv2
import os

reader = easyocr.Reader(['en'])

def extract_text(image_path):

    print("Reading:", image_path)

    print("Exists:", os.path.exists(image_path))

    img = cv2.imread(image_path)

    print("Image:", img)

    result = reader.readtext(image_path)

    text = ""

    for item in result:
        text += item[1] + " "

    return text.upper()