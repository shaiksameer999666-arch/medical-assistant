from rapidfuzz import fuzz
from .models import Medicine

def find_best_match(extracted_text):

    medicines = Medicine.objects.all()

    best_match = None

    highest_score = 0

    extracted_text = extracted_text.upper()

    for medicine in medicines:

        score = fuzz.partial_ratio(
            medicine.name.upper(),
            extracted_text
        )

        if score > highest_score:
            highest_score = score
            best_match = medicine

    if highest_score >= 70:
        return best_match, highest_score

    return None, highest_score