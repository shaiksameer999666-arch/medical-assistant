from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('home/', views.home, name='home'),
    path('upload/', views.upload_image, name='upload'),
    path('logout/', views.logout_view, name='logout'),
]