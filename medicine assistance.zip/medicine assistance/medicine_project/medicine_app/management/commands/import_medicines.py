import csv
from django.core.management.base import BaseCommand
from medicine_app.models import Medicine

class Command(BaseCommand):
    help = "Import medicines from CSV"

    def handle(self, *args, **kwargs):

        with open("datasets/medicines.csv", newline='', encoding='utf-8') as file:

            reader = csv.DictReader(file)

            for row in reader:

                Medicine.objects.create(
                    name=row["name"],
                    manufacturer=row["manufacturer"],
                    uses=row["uses"],
                    dosage=row["dosage"],
                    side_effects=row["side_effects"],
                    precautions=row["precautions"],
                    storage=row["storage"]
                )

        self.stdout.write(self.style.SUCCESS("Medicine data imported successfully!"))