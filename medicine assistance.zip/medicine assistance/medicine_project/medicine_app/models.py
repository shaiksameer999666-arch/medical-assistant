from django.db import models

class Medicine(models.Model):
    name = models.CharField(max_length=200)
    manufacturer = models.CharField(max_length=200)

    uses = models.TextField()

    dosage = models.TextField()

    side_effects = models.TextField()

    precautions = models.TextField()

    storage = models.TextField()

    image = models.ImageField(upload_to='medicine_images/', blank=True, null=True)

    def __str__(self):
        return self.name


class ScanHistory(models.Model):
    medicine = models.ForeignKey(Medicine, on_delete=models.CASCADE)

    uploaded_image = models.ImageField(upload_to='uploads/')

    confidence = models.FloatField(default=0)

    scan_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.medicine.name} ({self.scan_date})"