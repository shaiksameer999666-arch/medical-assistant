from django.shortcuts import render
from django.core.files.storage import FileSystemStorage

from .forms import ImageUploadForm
from .models import Medicine
from .ocr import extract_text
from .utils import find_best_match
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.shortcuts import redirect

# AI Model

def register_view(request):

    if request.method == "POST":
        form = UserCreationForm(request.POST)

        if form.is_valid():
            form.save()
            return redirect("login")

    else:
        form = UserCreationForm()

    return render(request, "register.html", {"form": form})


def login_view(request):

    if request.method == "POST":

        form = AuthenticationForm(request, data=request.POST)

        if form.is_valid():

            user = form.get_user()

            login(request, user)

            return redirect("home")

    else:

        form = AuthenticationForm()

    return render(request, "login.html", {"form": form})


def logout_view(request):

    logout(request)

    return redirect("login")


def home(request):

    if not request.user.is_authenticated:
        return redirect("login")

    return render(request, "home.html")



def upload_image(request):

    if request.method == "POST":

        form = ImageUploadForm(request.POST, request.FILES)

        if form.is_valid():

            image = form.cleaned_data["image"]

            fs = FileSystemStorage()

            filename = fs.save(image.name, image)

            uploaded_file_url = fs.url(filename)

            image_path = fs.path(filename)

            extracted_text = extract_text(image_path)

            medicine, confidence = find_best_match(extracted_text)

            return render(request, "result.html", {
                "uploaded_file_url": uploaded_file_url,
                "medicine": medicine,
                "confidence": round(confidence, 2),
                "extracted_text": extracted_text,
            })

    else:

        form = ImageUploadForm()

    return render(request, "upload.html", {
        "form": form
    })